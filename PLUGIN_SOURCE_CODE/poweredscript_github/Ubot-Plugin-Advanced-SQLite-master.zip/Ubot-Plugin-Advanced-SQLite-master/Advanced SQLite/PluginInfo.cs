﻿using System;
using System.IO;
using System.Reflection;
using System.Windows;

namespace Advanced_SQLite
{
    class PluginInfo
    {
        public static string HashCode
        {
            get
            {
                return "";
            }
        }
    }
}
