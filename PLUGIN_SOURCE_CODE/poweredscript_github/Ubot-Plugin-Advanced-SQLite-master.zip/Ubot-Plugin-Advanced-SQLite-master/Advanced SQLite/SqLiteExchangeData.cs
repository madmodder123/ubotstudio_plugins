﻿namespace Advanced_SQLite
{
    class SqLiteExchangeData
    {
        public static string DatabaseFile;
        public static string Debug;

    }
}
