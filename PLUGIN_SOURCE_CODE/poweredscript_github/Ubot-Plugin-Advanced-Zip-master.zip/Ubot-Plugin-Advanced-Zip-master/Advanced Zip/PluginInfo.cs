﻿using System;
using System.IO;

namespace Advanced_Zip
{
    using System.Reflection;
    public class PluginInfo
    { 
        public static string HashCode 
        {
        get
            {
                return "";
            } 
        } 
    }
}
