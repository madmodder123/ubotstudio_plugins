﻿using System;
using System.IO;
using System.Reflection;

namespace Advanced_Translate
{
    class PluginInfo
    {
        public static string HashCode
        {
            get
            {
                return "";
            }
        }
    }
}