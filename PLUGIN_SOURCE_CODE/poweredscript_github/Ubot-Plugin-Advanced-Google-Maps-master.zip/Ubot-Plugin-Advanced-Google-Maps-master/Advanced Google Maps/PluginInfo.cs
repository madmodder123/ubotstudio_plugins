﻿using System;
using System.IO;
using System.Reflection;

namespace Advanced_Google_Maps
{
    class PluginInfo
    {
        public static string HashCode
        {
            get
            {
                return "";
            }
        }
    }
}