﻿using OpenQA.Selenium;

namespace Advanced_WebDriver
{
    internal class Node
    {
        public static IWebDriver WebDriverConnect;
    }
}