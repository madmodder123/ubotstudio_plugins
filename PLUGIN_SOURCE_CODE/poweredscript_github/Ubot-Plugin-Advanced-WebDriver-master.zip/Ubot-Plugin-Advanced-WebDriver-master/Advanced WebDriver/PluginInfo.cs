﻿using System;
using System.IO;
using System.Reflection;

namespace Advanced_WebDriver
{
    [Obfuscation(Exclude = true, ApplyToMembers = true)]
    internal class PluginInfo
    {
        public static string HashCode
        {
            get
            {
                return "";
            }
        }
    }
}